file = open("fileTester.txt", "r")
line = file.read()
print(line)